		$(document).ready(function() {
			$("#news-slider").owlCarousel({
				items : 2,
				itemsDesktop:[1199,2],
				itemsDesktopSmall:[980,2],
				itemsMobile : [550,1],
				navigation:true,
				navigationText:["",""],
				autoPlay:false
			});
		});	  
		
				
		$(document).ready(function() {
			$("#news-slider2").owlCarousel({
				items : 4,
				itemsDesktop:[1199,4],
				itemsDesktopSmall:[980,2],
				itemsTablet:[650,1],
				pagination:false,
				navigation:true,
				navigationText:["",""]
			});
		});		
		
		$(document).ready(function() {
			$("#news-slider3").owlCarousel({
				items : 4,
				itemsDesktop:[1199,4],
				itemsDesktopSmall:[980,2],
				itemsTablet:[650,1],
				pagination:false,
				navigation:true,
				navigationText:["",""]
			});
		});	
		
		$(document).ready(function() {
			$("#news-slider4").owlCarousel({
				items : 4,
				itemsDesktop:[1199,4],
				itemsDesktopSmall:[980,2],
				itemsTablet:[650,1],
				pagination:false,
				navigation:true,
				navigationText:["",""]
			});
		});			
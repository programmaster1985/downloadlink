$('.second_open_bt').click(function() {  
    $('.second_open_bt').not(this).removeClass('second_open_bt_down');
    $(this).toggleClass('second_open_bt_down');
});


